#include "Def.hpp"
#include <cctype>

std::istream &readSpace(std::istream &is) {
  while (isspace(is.peek()))
    is.get();
  return is;
}

struct Syntax readList(std::istream &is);

// no leading space
struct Syntax readItem(std::istream &is) {
  if (is.peek() == '(') {
    is.get();
    return readList(is);
  }
  std::string s;
  do {
    int c = is.peek();
    if (c == '(' || c == ')' ||
        isspace(c) ||
        c == EOF)
      break;
    is.get();
    s.push_back(c);
  } while (true);
  // try parsing a integer
  bool neg = false;
  int n = 0;
  int i = 0;
  if (s[0] == '-') {
    i += 1;
    neg = true;
  } else if (s[0] == '+')
    i += 1;
  for (; i < s.size(); i++)
    if ('0' <= s[i] && s[i] <= '9')
      n = n * 10 + s[i] - '0';
    else
      goto identifier;
  if (neg)
    n = -n;
  return Syntax(new Number(n));
 identifier:
  // not a number
  return Syntax(new Identifier(s));
}

struct Syntax readList(std::istream &is) {
  struct List *stx = new List();
  while (readSpace(is).peek() != ')')
    stx->l.push_back(readItem(is));
  is.get(); // ')'
  return Syntax(stx);
}

Syntax readSyntax(std::istream &is) {
  return readItem(readSpace(is));
}

std::istream &operator>>(std::istream &is, Syntax &stx) {
  stx = readSyntax(is);
  return is;
}

/*--------------------------------*/

void Number::show(std::ostream &os) {
  os << "the-number-" << n;
}

void Identifier::show(std::ostream &os) {
  os << s;
}

void List::show(std::ostream &os) {
  os << '(';
  for (Syntax &stx : l) {
    stx.x->show(os);
    os << ' ';
  }
  os << ')';
}

void Value::show(std::ostream &os) {
  x->show(os);
}

std::ostream &operator<<(std::ostream &os, Value &v) {
  v.show(os);
  return os;
}

void ValueBase::showCdr(std::ostream &os) {
  os << " . ";
  show(os);
  os << ')';
}

void Void::show(std::ostream &os) {
  os << "#<void>";
}

void Integer::show(std::ostream &os) {
  os << n;
}

void Boolean::show(std::ostream &os) {
  os << (b ? "#t" : "#f");
}

void Symbol::show(std::ostream &os) {
  os << s;
}

void Null::show(std::ostream &os) {
  os << "()";
}

void Null::showCdr(std::ostream &os) {
  os << ')';
}

void Pair::show(std::ostream &os) {
  os << '(' << car;
  cdr.x->showCdr(os);
}

void Pair::showCdr(std::ostream &os) {
  os << ' ' << car;
  cdr.x->showCdr(os);
}

void Closure::show(std::ostream &os) {
  os << "#<procedure>";
}
