#ifndef DEF_HPP
#define DEF_HPP

#include <string>
#include <utility>
#include <vector>
#include <iostream>
#include <exception>

class RuntimeError : std::exception {};

struct Syntax;
struct Expr;
struct Value;

struct Assoc;

/*--------------------------------*/

Syntax readSyntax(std::istream &);

std::istream &operator>>(std::istream &, Syntax &);

struct SyntaxBase {
  virtual Expr parse(Assoc &) = 0;
  virtual void show(std::ostream &) = 0;
};

struct Syntax {
  SyntaxBase *x;
  Syntax(SyntaxBase *);
  Expr parse(Assoc &);
};

struct Number : SyntaxBase {
  int n;
  Number(int);
  virtual Expr parse(Assoc &) override;
  virtual void show(std::ostream &) override;
};

struct Identifier : SyntaxBase {
  std::string s;
  Identifier(const std::string &);
  virtual Expr parse(Assoc &) override;
  virtual void show(std::ostream &) override;
};

struct List : SyntaxBase {
  std::vector<Syntax> l;
  List();
  virtual Expr parse(Assoc &) override;
  virtual void show(std::ostream &) override;
};

/*--------------------------------*/

struct ExprBase {
  virtual Value eval(Assoc &) = 0;
};

struct Expr {
  ExprBase *x;
  Value eval(Assoc &);
};

struct Let : ExprBase {
  std::vector<std::pair<std::string, Expr>> bind;
  Expr body;
  virtual Value eval(Assoc &) override;
};

struct Lambda : ExprBase {
  std::vector<std::string> x;
  Expr e;
  virtual Value eval(Assoc &) override;
};

struct Apply : ExprBase {
  Expr rator;
  std::vector<Expr> rand;
  virtual Value eval(Assoc &) override;
};

struct Letrec : ExprBase {
  std::vector<std::pair<std::string, Expr>> bind;
  Expr body;
  virtual Value eval(Assoc &) override;
};

struct Var : ExprBase {
  std::string x;
  virtual Value eval(Assoc &) override;
};

struct Fixnum : ExprBase {
  int n;
  virtual Value eval(Assoc &) override;
};

struct If : ExprBase {
  Expr cond;
  Expr conseq;
  Expr alter;
  virtual Value eval(Assoc &) override;
};

struct True : ExprBase {
  virtual Value eval(Assoc &) override;
};

struct False : ExprBase {
  virtual Value eval(Assoc &) override;
};

struct Begin : ExprBase {
  std::vector<Expr> es;
  virtual Value eval(Assoc &) override;
};

struct Quote : ExprBase {
  Syntax s;
  virtual Value eval(Assoc &) override;
};

struct MakeVoid : ExprBase {
  virtual Value eval(Assoc &) override;
};

struct Binary : ExprBase {
  Expr rand1;
  Expr rand2;
  virtual Value evalRator(const Value &, const Value &) = 0;
  virtual Value eval(Assoc &) override;
};

struct Unary : ExprBase {
  Expr rand;
  virtual Value evalRator(const Value &) = 0;
  virtual Value eval(Assoc &) override;
};

struct Mult : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct Plus : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct Minus : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct Less : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct LessEq : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct Equal : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct GreaterEq : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct Greater : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct IsEq : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct Cons : Binary {
  virtual Value evalRator(const Value &, const Value &) override;
};

struct IsBoolean : Unary {
  virtual Value evalRator(const Value &) override;
};

struct IsFixnum : Unary {
  virtual Value evalRator(const Value &) override;
};

struct IsNull : Unary {
  virtual Value evalRator(const Value &) override;
};

struct IsPair : Unary {
  virtual Value evalRator(const Value &) override;
};

struct IsProcedure : Unary {
  virtual Value evalRator(const Value &) override;
};

struct Not : Unary {
  virtual Value evalRator(const Value &) override;
};

struct Car : Unary {
  virtual Value evalRator(const Value &) override;
};

struct Cdr : Unary {
  virtual Value evalRator(const Value &) override;
};

/*--------------------------------*/

struct ValueBase {
  virtual void show(std::ostream &) = 0;
  virtual void showCdr(std::ostream &);
};

std::ostream &operator<<(std::ostream &, Value &);

struct Value {
  ValueBase *x;
  Value(ValueBase *);
  void show(std::ostream &);
};

struct AssocList {
  std::string x;
  Value v;
  AssocList *next;
  AssocList(const std::string &, Value, AssocList *);
};

struct Assoc {
  AssocList *x;
  Assoc(AssocList *);
};

struct Void : ValueBase {
  Void();
  virtual void show(std::ostream &) override;
};
Value VoidV();

struct Integer : ValueBase {
  int n;
  Integer(int);
  virtual void show(std::ostream &) override;
};
Value IntegerV(int);

struct Boolean : ValueBase {
  bool b;
  Boolean(bool);
  virtual void show(std::ostream &) override;
};
Value BooleanV(bool);

struct Symbol : ValueBase {
  std::string s;
  Symbol(const std::string &);
  virtual void show(std::ostream &) override;
};
Value SymbolV(const std::string &);

struct Null : ValueBase {
  Null();
  virtual void show(std::ostream &) override;
  virtual void showCdr(std::ostream &) override;
};
Value NullV();

struct Pair : ValueBase {
  Value car;
  Value cdr;
  Pair(const Value &, const Value &);
  virtual void show(std::ostream &) override;
  virtual void showCdr(std::ostream &) override;
};
Value PairV(const Value &, const Value &);

struct Closure : ValueBase {
  std::vector<std::string> x;
  Expr e;
  Assoc env;
  Closure(const std::vector<std::string> &, const Expr &, const Assoc &);
  virtual void show(std::ostream &) override;
};
Value ClosureV(const std::vector<std::string> &, const Expr &, const Assoc &);

/*--------------------------------*/

Assoc empty();
Assoc extend(const std::string &, Value &, Assoc &);
Value find(const std::string &, Assoc &);

#endif
