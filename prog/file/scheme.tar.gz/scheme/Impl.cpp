#include "Def.hpp"

Syntax::Syntax(SyntaxBase *x) : x(x) {}
Expr Syntax::parse(Assoc &e) {
  return x->parse(e);
}

Number::Number(int n) : n(n) {}
Expr Number::parse(Assoc &e) {}

Identifier::Identifier(const std::string &s) : s(s) {}
Expr Identifier::parse(Assoc &e) {}

List::List() : l() {}
Expr List::parse(Assoc &e) {}

/*--------------------------------*/

Value Expr::eval(Assoc &e) {
  return x->eval(e);
}

Value Let::eval(Assoc &e) {}

Value Lambda::eval(Assoc &e) {}

Value Apply::eval(Assoc &e) {}

Value Letrec::eval(Assoc &e) {}

Value Var::eval(Assoc &e) {}

Value Fixnum::eval(Assoc &e) {}

Value If::eval(Assoc &e) {}

Value True::eval(Assoc &e) {}

Value False::eval(Assoc &e) {}

Value Begin::eval(Assoc &e) {}

Value Quote::eval(Assoc &e) {}

Value MakeVoid::eval(Assoc &e) {}

Value Binary::eval(Assoc &e) {
  return evalRator(rand1.eval(e), rand2.eval(e));
}

Value Unary::eval(Assoc &e) {
  return evalRator(rand.eval(e));
}

Value Mult::evalRator(const Value &rand1, const Value &rand2) {}

Value Plus::evalRator(const Value &rand1, const Value &rand2) {}

Value Minus::evalRator(const Value &rand1, const Value &rand2) {}

Value Less::evalRator(const Value &rand1, const Value &rand2) {}

Value LessEq::evalRator(const Value &rand1, const Value &rand2) {}

Value Equal::evalRator(const Value &rand1, const Value &rand2) {}

Value GreaterEq::evalRator(const Value &rand1, const Value &rand2) {}

Value Greater::evalRator(const Value &rand1, const Value &rand2) {}

Value IsEq::evalRator(const Value &rand1, const Value &rand2) {}

Value Cons::evalRator(const Value &rand1, const Value &rand2) {}

Value IsBoolean::evalRator(const Value &rand) {}

Value IsFixnum::evalRator(const Value &rand) {}

Value IsNull::evalRator(const Value &rand) {}

Value IsPair::evalRator(const Value &rand) {}

Value IsProcedure::evalRator(const Value &rand) {}

Value Not::evalRator(const Value &rand) {}

Value Car::evalRator(const Value &rand) {}

Value Cdr::evalRator(const Value &rand) {}

/*--------------------------------*/

Value::Value(ValueBase *x) : x(x) {}

Void::Void() {}
Value VoidV() {
  return Value(new Void());
}

Integer::Integer(int n) : n(n) {}
Value IntegerV(int n) {
  return Value(new Integer(n));
}

Boolean::Boolean(bool b) : b(b) {}
Value BooleanV(bool b) {
  return Value(new Boolean(b));
}

Symbol::Symbol(const std::string &s) : s(s) {}
Value SymbolV(const std::string &s) {
  return Value(new Symbol(s));
}

Null::Null() {}
Value NullV() {
  return Value(new Null());
}

Pair::Pair(const Value &car, const Value &cdr) : car(car), cdr(cdr) {}
Value PairV(const Value &car, const Value &cdr) {
  return Value(new Pair(car, cdr));
}

Closure::Closure(const std::vector<std::string> &xs, const Expr &e, const Assoc &env)
  : x(xs), e(e), env(env) {}
Value ClosureV(const std::vector<std::string> &xs, const Expr &e, const Assoc &env) {
  return Value(new Closure(xs, e, env));
}


AssocList::AssocList(const std::string &x, Value v, AssocList *next)
  : x(x), v(v), next(next) {}

Assoc::Assoc(AssocList *x) : x(x) {}

Assoc empty() {
  return Assoc(NULL);
}

Assoc extend(std::string &x, Value &v, Assoc &l) {
  return Assoc(new AssocList(x, v, l.x));
}

Value find(std::string &x, Assoc &l) {
  for (AssocList *i = l.x; i != NULL; i = i->next)
    if (x == i->x)
      return i->v;
  return Value(NULL);
}
