#include "Def.hpp"
#include <sstream>

int main() {
  std::istringstream input("(41243 jla (lkjalksd) (((()))) (()()()dsa()dsa)+432 +1 1+ ka.fasdf -1 1-1 1-)");
  Syntax stx = readSyntax(input);
  stx.x->show(std::cout);
  PairV(PairV(SymbolV("x"), VoidV()), PairV(IntegerV(0), PairV(BooleanV(true), NullV()))).show(std::cout);
  return 0;
}
