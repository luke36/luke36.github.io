# 2048
A simple command line version of the game 2048.
Runs on Windows ONLY.
