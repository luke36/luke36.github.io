/* ../src/mixcfg.h.  Generated automatically by configure.  */
/* This -*- C -*- file is meant to be processed by the configure script */

/* Some systems (eg. Debian GNU/Linux) put <forms.h> in <X11/forms.h>. */
/* #undef MIX_USE_X11_FORMS */

/* Define this if your compiler doesn't support the new C++ 'bool' type */
/* #undef MIX_NEED_BOOL */

/* Define if your system supports fabsf() */
#define MIX_HAVE_FABSF 1

/* Define if your system supports rint() */
#define MIX_HAVE_RINT 1

/* Define if your system supports getrusage() */
#define MIX_HAVE_GETRUSAGE 1

/* Define if your system does not support getrusage() but supports times() */
#define MIX_HAVE_TIMES 1

/* Define if your system supports random() as opposed to just rand() */
#define MIX_HAVE_RANDOM 1

/* Define if your system uses/needs <unistd.h> */
#define HAVE_UNISTD_H 1

/* Stuff determining the presence of support for alloca() */
/* #undef HAVE_ALLOCA_H */
#define HAVE_ALLOCA 1

/* Define if ANSI Standard C++ Library iostreams are available and */
/* you want to use them. */
/* #undef MIX_ANSI_IOSTREAMS */

/* 
   Global safety policy for MixKit software.

   Safety levels:

       -2 Reckless
       -1 Optimized
        0 Normal
        1 Cautious
        2 Paranoid

*/
#ifndef SAFETY
#define SAFETY 0
#endif

/* Define if Sam Leffler's libtiff is available */
#define MIX_HAVE_LIBTIFF 1

/* Define if libpng is available */
#define MIX_HAVE_LIBPNG 1

/* ***** OpenGL configuration section ***** */

/* Define to the name of OpenGL implementation (e.g., "OpenGL" or "Mesa") */
#define MIX_HAVE_OPENGL "OpenGL"

/* Define if glPolygonOffsetEXT is available */
#define MIX_HAVE_POLYOFFSET_EXT 1

/* Define if glPolygonOffset is available */
#define MIX_HAVE_POLYOFFSET 1

/* Define if glDrawArraysEXT is available */
#define MIX_HAVE_VERTARRAYS 1
