module.exports = grammar({
  name: 'miniml',

  rules: {
    program: $ => $._declr,
    _declr: $ => choice(
      $.ddata,
      $.dlet,
      $.dexp,
    ),
    ddata: $ => seq('data', $.conid, '=', $._constr, $._declr),
    dlet: $ => seq('let', $.varid, '=', $._exp, $._declr),
    dexp: $ => seq('let', '_', '=', $._exp),

    _constr: $ => choice(
      $.constrcons
    ),
    constrcons: $ => seq('|', $.conid, $._typelist, optional($._constr)),

    _typelist: $ => choice(
      $.typelistcons,
      $.typelistnil
    ),
    typelistcons: $ => seq($._type, $._typelist),
    typelistnil: $ => '.',

    _type1: $ => choice(
      $.tcon,
      $.tstr,
      $.tbool,
      $.tint,
      $.tunit,
      seq('(', $._type, ')'),
    ),
    _type: $ => choice(
      $._type1,
      $.tarrow,
    ),
    tarrow: $ => seq($._type1, '->', $._type),
    tcon: $ => $.conid,
    tstr: $ => 'String',
    tbool: $ => 'Bool',
    tint: $ => 'Int',
    tunit: $ => '()',

    _exp1: $ => choice(
      seq('(', $._exp, ')'),
      $.evar,
      $.ebool,
      $.eunit,
      $.eint,
      $.estr,
      $.ereadint,
      $.ecase,
    ),
    _exp2: $ => choice(
      $._exp1,
      $.eapp,
      $.econ,
      $.efix,
      $.eseq,
      $.econcat,
      $.ecopy,
      $.elength,
      $.estreq,
      $.eprint,
    ),
    _exp3: $ => choice (
      $._exp2,
      $.epow
    ),
    _exp4: $ => choice (
      $._exp3,
      $.emul
    ),
    _exp5: $ => choice (
      $._exp4,
      $.eplus,
      $.esub,
    ),
    _exp6: $ => choice (
      $._exp5,
      $.eeq,
      $.ele,
    ),
    _exp: $ => choice (
      $._exp6,
      $.eabs,
      $.elet,
      $.eif,
    ),
    evar: $ => $.varid,
    ebool: $ => choice('True', 'False'),
    eunit: $ => '()',
    eint: $ => /[0-9]+/,
    estr: $ => /"[^"]*"/,
    ereadint: $ => 'readInt',
    eapp: $ => choice (
      seq($._exp1, $._exp1),
      seq($.eapp, $._exp1)
    ),
    econ: $ => seq($.conid, optional($._explist)),
    efix: $ => seq('fix', $._exp1),
    eseq: $ => seq('seq', $._exp1, $._exp1),
    econcat: $ => seq('concat', $._exp1, $._exp1),
    ecopy: $ => seq('copy', $._exp1),
    elength: $ => seq('length', $._exp1),
    estreq: $ => seq('streq', $._exp1, $._exp1),
    eprint: $ => seq('print', $._exp1),
    epow: $ => seq($._exp2, '^', $._exp3),
    emul: $ => seq($._exp4, '*', $._exp3),
    eplus: $ => seq($._exp5, '+', $._exp4),
    esub: $ => seq($._exp5, '-', $._exp4),
    eeq: $ => seq($._exp6, '==', $._exp5),
    ele: $ => seq($._exp6, '<=', $._exp5),
    eabs: $ => seq('\\', $.varid, ':', $._type, '=>', $._exp),
    elet: $ => seq('let', $.varid, '=', $._exp, 'in', $._exp),
    eif: $ => seq('if', $._exp, 'then', $._exp, 'else', $._exp),
    ecase: $ => seq('case', $._exp, 'of', $._branch, 'end'),

    _branch: $ => choice(
      $.branchcons
    ),
    branchcons: $ => seq('|', $.pattern, '=>', $._exp, optional($._branch)),
    pattern: $ => seq($.conid, optional($._patternidlist)),
    _patternidlist: $ => choice(
      $.patternidcons
    ),
    patternidcons: $ => seq($.varid, optional($._patternidlist)),

    _explist: $ => choice(
      $.explistcons
    ),
    explistcons: $ => seq($._exp1, optional($._explist)),

    varid: $ => /[a-z][a-zA-Z]*/,
    conid: $ => /[A-Z][a-zA-Z]*/,
  }
});

