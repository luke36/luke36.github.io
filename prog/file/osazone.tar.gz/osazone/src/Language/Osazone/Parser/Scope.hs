module Language.Osazone.Parser.Scope where

import Utils.ErrorMessage
import Language.Osazone.AST
import Language.Osazone.Parser.Combinators
import Language.Osazone.Parser.Token
import Language.Osazone.Parser.GeneralParser
import Lifting.Scope

import Text.Parsec
import Text.Read (read)

data FrontendRule
  = FSPImportAll
  | FSPExportAll
  | FSPImport [Int]
  | FSPExport [Int]
  | FSPImportExcept [Int]
  | FSPExportExcept [Int]
  | FSPBind [Int] [Int]
  | FSPDef [Int]

pCon :: P QName
pCon = QName <$> conId
   <|> QName <$> conOp

pInt :: P Int
pInt = read <$> litNum

pFrontendRule :: P FrontendRule
pFrontendRule =
      do exact KwImport
         (FSPImport <$> many1 pInt) <|> (do exact KwAll
                                            return FSPImportAll)
                                    <|> (do exact KwExcept
                                            FSPImportExcept <$> many1 pInt)
  <|> do exact KwExport
         (FSPExport <$> many1 pInt) <|> (do exact KwAll
                                            return FSPExportAll)
                                    <|> (do exact KwExcept
                                            FSPExportExcept <$> many1 pInt)
  <|> do exact KwBind
         binders <- many1 pInt
         exact KwIn
         bodies <- many1 pInt
         return $ FSPBind binders bodies
  <|> do exact KwDef
         defs <- many1 pInt
         return $ FSPDef defs

ppScopeRuleSet :: [Module] -> QName -> [FrontendRule] -> [ScopeRule]
ppScopeRuleSet ms q@(QName [mod, con]) rs =
  let m = findModule ms
      n = findConstr $ typeDecl m
  in concatMap (ppScopeRule n) rs
  where findModule (m:ms) | moduleName m == QName [mod] = m
                          | otherwise = findModule ms
        findConstrInDD :: [(String, [Type])] -> Maybe Int
        findConstrInDD [] = Nothing
        findConstrInDD ((con', ts):cs) | con == con' = Just $ length ts
                                       | otherwise   = findConstrInDD cs
        findConstr (dd:dds) =
          case findConstrInDD $ ddConstructors dd of
            Just n  -> n
            Nothing -> findConstr dds
        fromOne = iterate (+1) 1
        ppScopeRule :: Int -> FrontendRule -> [ScopeRule]
        ppScopeRule n FSPImportAll = take n $ map (SRImport q) fromOne
        ppScopeRule n FSPExportAll = take n $ map (SRExport q) fromOne
        ppScopeRule n (FSPImport ns) = map (SRImport q) ns
        ppScopeRule n (FSPExport ns) = map (SRExport q) ns
        ppScopeRule n (FSPImportExcept ns) =
          [ SRImport q i | i <- take n fromOne, i `notElem` ns ]
        ppScopeRule n (FSPExportExcept ns) =
          [ SRExport q i | i <- take n fromOne, i `notElem` ns ]
        ppScopeRule n (FSPBind is js) = [ SRBind q i j | i <- is, j <- js]
        ppScopeRule _ (FSPDef defs) = [ SRBind q i i | i <- defs ]

pScopeRuleSet :: [Module] -> P [ScopeRule]
pScopeRuleSet ms =
  do con <- pCon
     exact KwOpDoubleColon
     rs <- many pFrontendRule
     return $ ppScopeRuleSet ms con rs

pScopeRuleLib :: [Module] -> P ScopeRuleLib
pScopeRuleLib ms = initCoreScope . concat <$> many (pScopeRuleSet ms)

pMultiScopeRuleLib :: [Module] -> P [(String, ScopeRuleLib)]
pMultiScopeRuleLib ms = many do
  exact KwRules
  sname <- notQualified conId
  lib <- pScopeRuleLib ms
  return (sname, lib)

parseScope :: [Module] -> FilePath -> IO [(String, ScopeRuleLib)]
parseScope ms path = do
  src <- readFile path
  let res = parseFile (pMultiScopeRuleLib ms) path src
  case res of
    Left err  -> error $ show err
    Right lib -> return lib

