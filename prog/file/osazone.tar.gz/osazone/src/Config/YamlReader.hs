{-# LANGUAGE DeriveGeneric        #-}
{-# LANGUAGE OverloadedStrings    #-}
{-# LANGUAGE UndecidableInstances #-}
module Config.YamlReader where

import Utils.AnsiPretty (Pretty)
import Utils.StringTemplate

import Data.Char as C
import Data.Map as M
import Data.Text
import Data.Yaml
import GHC.Generics (Generic)

data YamlConfig = YamlConfig
  { name      :: Text
  , version   :: Text
  , extension :: Text
  , ide       :: Text
  , lib       :: Text
  , repl      :: M.Map String String
  , files     :: [String]
  , scope     :: String
  } deriving (Eq, Show, Ord, Generic)

instance FromJSON YamlConfig where
instance ToJSON YamlConfig where

data LiftingConfig = LiftingConfig
  { surfName :: Text
  , corePath :: Text
  } deriving (Eq, Show, Ord)

instance FromJSON LiftingConfig where
  parseJSON (Object v) = LiftingConfig
    <$> v .: "name"
    <*> v .: "core"
  parseJSON _ = undefined

class LangConfig cfg where
  getName :: cfg -> Text

instance LangConfig YamlConfig where
  getName cfg = name cfg

instance LangConfig LiftingConfig where
  getName cfg = surfName cfg

instance LangConfig a => PreSTMP a where
  putInSTMP config stmp =
    render $ newSTMP stmp
      <~~ ("lang", n)
      <~~ ("name", (\(h:t) -> C.toLower h:t) n)
      <~~ ("Name", (\(h:t) -> C.toUpper h:t) n)
    where n = unpack (getName config)
