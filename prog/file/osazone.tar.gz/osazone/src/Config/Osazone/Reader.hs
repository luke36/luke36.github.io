{-# LANGUAGE OverloadedStrings #-}
module Config.Osazone.Reader (readLang) where

import Config.YamlReader as Y
import Language.Osazone
import Language.Osazone.Parser.Scope
import Language.Osazone.Parser.Translation (parseOsa)
import Utils.AnsiPretty
import Utils.ErrorMessage (ErrMsg (ErrMsg), raiseErrIO)

import Control.Monad.Catch (MonadCatch (catch), MonadThrow (throwM))
import Control.Monad.State
import Data.Bifunctor (Bifunctor (bimap))
import qualified Data.ByteString as S
import Data.List (partition)
import Data.Map (fromList)
import Data.Text (unpack)
import Data.Yaml (ParseException, decodeThrow)
import Debug.Trace
import System.Directory (doesDirectoryExist, doesFileExist)
import System.FilePath ((<.>), (</>))

data ModulePath
  = ProjPath FilePath
  | LibPath FilePath

readLang :: FilePath -> IO Lang
readLang path = do
  config <- readYaml path
  let name = unpack (Y.name config)
  let version = unpack (Y.version config)
  let extension = unpack (Y.extension config)
  let scope = Y.scope config
  modules <- readModules path
  let (proj, lib) = partition fst modules
  scoperules <- parseScope (map snd proj) $ path </> scope
  return Lang
    { langName      = name
    , langVersion   = version
    , langExtension = extension
    , langModules   = (map snd proj, map snd lib)
    , langConfig    = config
    , langScope     = scoperules
    }

readYaml :: FilePath -> IO YamlConfig
readYaml path = do
  src <- S.readFile (path </> "language.yaml")
  decodeThrow src `catch` \(e :: ParseException) -> do
    raiseErrIO 20 (viaShow e)

readModules :: FilePath -> IO [(Bool, Module)]
readModules path = do
  config <- readYaml path
  let projPath = path </> "src/"
  let libPath = unpack (lib config)
  let libPath' = path </> libPath
  mod <- parseOsa (path </> "src/Lang.osa")
  -- read prelude module
  prelude <- parseOsa (libPath' </> "Prelude.osa")
  trans <- parseOsa (libPath' </> "Meta/Monad/Trans.osa")
  flip evalStateT (projPath, libPath', []) do
    modDeps <- getDependencies (True, mod)
    preludeDeps <- getDependencies (False, prelude)
    transDeps <- getDependencies (False, trans)
    return $ modDeps ++ preludeDeps ++ transDeps

getDependencies :: (Bool, Module) -> StateT (FilePath, FilePath, [QName]) IO [(Bool, Module)]
getDependencies p@(fromProj, mod) = do
  let name = moduleName mod
  (projPath, libPath, curr) <- get
  if name `elem` curr then return [] else do
    put (projPath, libPath, name : curr)
    let qnames = imports mod
    deps <- mapM (readModuleFromQName (moduleName mod)) qnames
    mods <- mapM getDependencies deps
    return (p : concat mods)

-- Given the root path of a project, get the parsed module of the QName
readModuleFromQName :: QName -> QName -> StateT (FilePath, FilePath, [QName]) IO (Bool, Module)
readModuleFromQName imported qname = do
  (projPath, libPath, curr) <- get
  res <- lift (searchQName projPath qname)
  res' <- lift (searchQName libPath qname)
  case (res, res') of
    (Just p, _) -> lift ((,) True <$> parseOsa p)
    (_, Just p') -> lift ((,) False <$> parseOsa p')
    _ -> lift $ raiseErrIO 21 $
      "Module" <+> colored Blue (viaShow qname)
        <+> "imported in" <+> colored Blue (viaShow imported)
        <+> "is not found in"
        <|> indent 2 (vsep
          [ "(proj)" <+> viaShow projPath
          , "(lib) " <+> viaShow libPath
          ])

-- Given a path, get the real file path of the QName
searchQName :: FilePath -> QName -> IO (Maybe FilePath)
searchQName path (QName []) = return Nothing
searchQName path (QName [name]) = do
  let modPath = path </> name <.> "osa"
  ex <- doesFileExist modPath
  if ex then return (Just modPath) else return Nothing
searchQName path qname@(QName (q : qs)) = do
  let modPath = path </> show qname <.> "osa"
  let dir = path </> q
  fileExt <- doesFileExist modPath
  dirExt <- doesDirectoryExist dir
  if fileExt then return (Just modPath)
  else if dirExt then searchQName dir (QName qs)
  else return Nothing
