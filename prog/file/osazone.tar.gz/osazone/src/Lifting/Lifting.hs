module Lifting.Lifting where

import Config.YamlReader (LiftingConfig)
import Language.Osazone (Lang)
import Lifting.Extension
import Lifting.Scope
import Lifting.Lifting.SugarLifting (liftSugar)

lifting :: LiftingConfig -> ExtensionFile -> Lang -> Lang
lifting config extfile core = foldl (flip liftExtension) core (extensions extfile)

liftExtension :: Extension -> Lang -> Lang
liftExtension (ExtSugars sugars) lang =
  liftScope sugars $ foldl (flip liftSugar) lang sugars

