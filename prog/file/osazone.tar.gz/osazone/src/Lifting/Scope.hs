{-# LANGUAGE OverloadedStrings #-}
module Lifting.Scope where

import Language.Osazone
import Language.Osazone.AST
import Lifting.Sugar
import Utils.Pretty
import Utils.System (createAndWriteFile)

import Control.Monad.State
import Data.Traversable
import Data.List as L (delete, map, intersect, partition, intercalate, iterate, union, (!!))
import Data.Maybe (maybe, mapMaybe)
import Data.Map as M
  (Map, (!), singleton, unions, union, unionWith, unionsWith, map, keys, elems, member, notMember, insert, insertWith, update, empty, fromListWith, lookup)
import System.FilePath ((</>))
import Text.RawString.QQ
import Text.Printf
import SAT.MiniSat

data HoleExpr
  = HEHole   Int
  | HENode   QName [HoleExpr]
  -- they only appear on the right hand side
  | HEVarDecl QName
  | HEVarUse  QName
  | HELit
  deriving (Show, Eq)

type ScopeRuleConj = [ScopeRule]

newtype Constraint =
  Constraint { unConstraint :: (ScopeRuleConj, ScopeRuleConj) }
  deriving (Show, Eq)

newtype ScopeSugar = ScopeSugar { unSS :: (HoleExpr, HoleExpr) }

data HolePath
  = HPEnd
  | HPMore QName Int HolePath
  deriving (Show, Eq)

fromOne :: [Int]
fromOne = iterate (+1) 1

-- could improve
locateHoles :: HoleExpr -> Map Int HolePath
locateHoles (HEVarDecl _) = empty
locateHoles (HEVarUse _)  = empty
locateHoles HELit         = empty
locateHoles (HEHole x)    = singleton x HPEnd
locateHoles (HENode con childs) =
  unions $ zipWith ithRecording childs fromOne
  where
    ithRecording x i = M.map (HPMore con i) $ locateHoles x

--             i           j
genDeriv :: HolePath -> HolePath -> ScopeRuleConj
genDeriv HPEnd HPEnd            = []
genDeriv (HPMore con i p) HPEnd = SRExport con i : genDeriv p HPEnd
genDeriv HPEnd (HPMore con j q) = SRImport con j : genDeriv HPEnd q
genDeriv (HPMore con i p) (HPMore _ j q)
  | i == j    = genDeriv p q
  | otherwise = SRBind con i j : genDeriv p HPEnd ++ genDeriv HPEnd q

genConstraint :: ScopeSugar -> [Constraint]
genConstraint (ScopeSugar (c1, c2)) =
  let holes = intersect (keys p1) (keys p2)
      pair  = [ (x, y) | x <- holes, y <- holes, x /= y ]
  in L.map genBind pair
  ++ L.map genImport holes
  ++ L.map genExport holes
  where
    p1             = locateHoles c1
    p2             = locateHoles c2
    genBind (x, y) = Constraint (genDeriv (p1 ! x) (p1 ! y),
                                 genDeriv (p2 ! x) (p2 ! y))
    genImport x    = Constraint (genDeriv HPEnd $ p1 ! x, genDeriv HPEnd $ p2 ! x)
    genExport x    = Constraint (genDeriv (p1 ! x) HPEnd, genDeriv (p2 ! x) HPEnd)

data SolvingEnv = SolvingEnv
  { coreRules  :: ScopeRuleLib
  , surfRules  :: ScopeRuleLib
  , constraint :: [Constraint]
  }

constrOfRule :: ScopeRule -> QName
constrOfRule (SRImport con _) = con
constrOfRule (SRExport con _) = con
constrOfRule (SRBind con _ _) = con

simplifyKnown :: [Constraint] -> ScopeRuleLib -> ScopeRuleLib -> [Constraint]
simplifyKnown eqs (ScopeRuleLib m1) (ScopeRuleLib m2) = L.map simplifyOne eqs
  where
    noRule r =
      (notMember con m1 || notElem r (m1 ! con)) &&
      (notMember con m2 || notElem r (m2 ! con))
      where con = constrOfRule r
    simplifyOne (Constraint (l, r)) = Constraint (filter noRule l, filter noRule r)

extractFinished :: [Constraint] -> ([ScopeRule], [Constraint])
extractFinished eqs =
  let (triv, comp) = partition hasTrivSide eqs
  in (concatMap extractOne triv, comp)
  where hasTrivSide (Constraint ([], _)) = True
        hasTrivSide (Constraint (_, [])) = True
        hasTrivSide _                    = False
        extractOne (Constraint ([], rs)) = rs
        extractOne (Constraint (rs, [])) = rs

addOrConflict :: [ScopeRule] -> SolvingEnv -> SolvingEnv
addOrConflict rs env@SolvingEnv{..} = foldl addOne env rs
  where
    addOne env@SolvingEnv{..} r = env{ surfRules = ScopeRuleLib $ insertWith L.union con [r] $ unSRL surfRules }
      -- | member con $ unSRL coreRules =
          -- if r `elem` unSRL coreRules ! con then env
          -- else error "error: conflicting scope"
      -- | otherwise =
          -- env{ surfRules = ScopeRuleLib $ insertWith L.union con [r] $ unSRL surfRules }
      where con = constrOfRule r

solveConstraints :: SolvingEnv -> SolvingEnv
solveConstraints env@SolvingEnv{..} =
  let constraint'              = simplifyKnown constraint coreRules surfRules
      (newFacts, constraint'') = extractFinished constraint'
  in
    if null newFacts then env
    else solveConstraints $ (addOrConflict newFacts env){constraint = constraint''}

inferScope :: ScopeRuleLib -> [ScopeSugar] -> ScopeRuleLib
inferScope lib sgs =
  let SolvingEnv{..} = solveConstraints initEnv
  in ScopeRuleLib $ M.unionWith (++) (unSRL coreRules) (unSRL surfRules)
  where
    constraints = concatMap genConstraint sgs
    initEnv     = SolvingEnv
      {
        coreRules  = lib,
        surfRules  = ScopeRuleLib empty,
        constraint = constraints
      }

liftScope :: [Sugar] -> Lang -> Lang
liftScope sgs lang@Lang{..} =
  lang{ langScope = L.map updateLib langScope }
  where ssg = L.map sugarToScopeSugar sgs
        updateLib (sname, lib) = (sname, inferScope lib ssg)

initCoreScope :: [ScopeRule] -> ScopeRuleLib
initCoreScope rs = ScopeRuleLib $ fromListWith (++) $ L.map labelRule rs
  where labelRule r = (constrOfRule r, [r])

exprToHoleExpr :: Map String Int -> Expr -> HoleExpr
exprToHoleExpr hs = toHole
  where
    -- we cannot distinguish declaration and reference now
    toHole (EVar x@(QName [s]))     = maybe (HEVarUse x) HEHole $ M.lookup s hs
    toHole (EVarOp x@(QName [s]))   = maybe (HEVarUse x) HEHole $ M.lookup s hs
    toHole (EVar x)                 = HEVarUse x
    toHole (EVarOp x)               = HEVarUse x
    toHole (ECon con)               = HENode con []
    toHole (EConOp con)             = HENode con []
    toHole (ELitNum _)              = HELit
    toHole (ELitStr _)              = HELit
    toHole (EApp (ECon con : es))   = HENode con $ L.map toHole es
    toHole (EApp (EConOp con : es)) = HENode con $ L.map toHole es
    -- They might get supported in the future
    toHole (ETuple _) = error "error: meta tuple is not supported"
    toHole (EList _)  = error "error: meta list is not supported"
    -- They are unlikely to be so
    toHole (ELam {})   = error "error: meta lambda is not supported"
    toHole (EApp _)    = error "error: meta application is not supported"
    toHole (EMatch {}) = error "error: meta match is not supported"
    toHole (ELet {})   = error "error: meta binding is not supported"
    toHole (EIf {})    = error "error: meta conditional is not supported"

patternToHoleExprRec :: Pattern -> State (Int, Map String Int) HoleExpr
patternToHoleExprRec (PVar x)        = do (i, m) <- get
                                          put (i + 1, insert x i m)
                                          return $ HEHole i
patternToHoleExprRec (PCon con ps)   = HENode con <$> mapM patternToHoleExprRec ps
patternToHoleExprRec (PConOp con ps) = HENode con <$> mapM patternToHoleExprRec ps
patternToHoleExprRec PWildcard       = do (i, m) <- get
                                          put (i + 1, m)
                                          return $ HEHole i
patternToHoleExprRec (PTuple {})     = error "error: meta tuple is not supported"
patternToHoleExprRec (PList {})      = error "error: meta list is not supported"

patternToHoleExpr :: Pattern -> (Map String Int, HoleExpr)
patternToHoleExpr p = (m, he)
  where (he, (_, m)) = runState (patternToHoleExprRec p) (0, empty)

sugarToScopeSugar :: Sugar -> ScopeSugar
sugarToScopeSugar Sugar{..} =
  let (m, l) = patternToHoleExpr $ PCon (QName ["Lang", sgName]) sgParams
      r      = exprToHoleExpr m $ exposeBody sgDef
  in ScopeSugar (l, r)
  where exposeBody (SgExprFresh _ def) = exposeBody def
        exposeBody (SgExprExpr def)    = def

scopePPLang :: Lang -> Lang
scopePPLang l@Lang{..} =
  l{ langScope = L.map f langScope}
  where f l = foldl scopePPModule l $ fst langModules

scopePPModule :: (String, ScopeRuleLib) -> Module -> (String, ScopeRuleLib)
scopePPModule lib Module{..} = foldl (scopePPData moduleName) lib typeDecl

withScopeAnnotation :: String -> [Annotation] -> Bool
withScopeAnnotation _ [] = False
withScopeAnnotation sname (ann:anns)
  | annoTitle ann == "scope" && elem sname (annoArgs ann) = True
  | otherwise = withScopeAnnotation sname anns

scopePPData :: QName -> (String, ScopeRuleLib) -> DataDeclaration
            -> (String, ScopeRuleLib)
scopePPData (QName mod) l@(sname, lib) DataDeclaration{..}
  | withScopeAnnotation sname ddAnnotation = (sname, foldl scopePPConstr lib ddConstructors)
  | otherwise = l
  where scopePPConstr lib@(ScopeRuleLib m) (con, pts) =
          if member fullName m then lib
          else ScopeRuleLib $ insert fullName allImports m
          where fullName = QName $ mod ++ [con]
                n = length pts
                allImports = L.map (SRImport fullName) $ take n fromOne

needScoping :: String -> Lang -> Type -> Bool
needScoping _ _ (TyCon (QName ["Meta","Identifier","Id"])) = True
needScoping sname Lang{..} (TyCon (QName [mod, d])) =
  let ms = fst langModules
      mLang = findMod ms
      dd = Just . findDD . typeDecl =<< mLang
  in maybe False (withScopeAnnotation sname . ddAnnotation) dd
  where findMod (m:ms) | moduleName m == QName [mod] = Just m
                       | otherwise = findMod ms
        findMod [] = Nothing
        findDD (dd:dds) | ddTypeName dd == d = dd
                        | otherwise = findDD dds
needScoping _ _ _ = False

filterExports :: [ScopeRule] -> [Int]
filterExports = mapMaybe extractIndex
  where extractIndex (SRExport _ i) = Just i
        extractIndex _              = Nothing

filterImports :: [ScopeRule] -> [Int]
filterImports = mapMaybe extractIndex
  where extractIndex (SRImport _ i) = Just i
        extractIndex _              = Nothing

filterBinds :: [ScopeRule] -> Int -> [Int]
filterBinds rs j = mapMaybe extractIndex rs
  where extractIndex (SRBind _ i j') | j == j' = Just i
        extractIndex _ = Nothing

data ScopeCodeEnv = ScopeCodeEnv
  { sceExtraParam :: forall ann. Doc ann
  , sceLang       :: Lang
  , sceModule     :: QName
  , sceScope      :: String
  }

getScopeRules :: ScopeCodeEnv -> String -> [ScopeRule]
getScopeRules ScopeCodeEnv{..} con =
  unSRL (findLib $ langScope sceLang) ! QName (unwrapQName sceModule ++ [con])
  where findLib ((sname, lib) : libs) | sname == sceScope = lib
        findLib (_ : libs) = findLib libs

numberChilds :: ScopeCodeEnv -> [Type] -> ([Int], Doc ann)
numberChilds ScopeCodeEnv{..} tys =
  let tags = L.map (needScoping sceScope sceLang) tys
      is  = mapMaybe (\(x, s) -> if s then Just x else Nothing) $
            zip fromOne tags
  in (is, sceExtraParam <> doc 1 tags)
  where doc :: Int -> [Bool] -> Doc ann
        doc _ []           = ""
        doc i (True : ts)  = "e" <> pretty i <+> doc (i + 1) ts
        doc i (False : ts) = "_" <+> doc (i + 1) ts

genComma :: (a -> Doc ann) -> [a] -> Doc ann
genComma f xs = concatWith (\a b -> a <> "," <+> b) $ L.map f xs

genCommaLine :: (a -> Doc ann) -> [a] -> Doc ann
genCommaLine f xs = concatWith (\a b -> a <> "," <|> b) $ L.map f xs

genFullName :: QName -> String -> Doc ann
genFullName mod con = pretty mod <> "." <> pretty con

genICExportConstr :: ScopeCodeEnv -> (String, [Type]) -> Doc ann
genICExportConstr env@ScopeCodeEnv{..} (con, tys) =
  let (is, childs) = numberChilds env tys
  in functionName <+> "p (" <> genFullName sceModule con <+> childs <> ") =" <|>
     indent 2 ("let" <+> align (vsep $ L.map genICBind is) <|>
               "in IC (Map.unionsWith (++) [" <> genICMaps exports <> "]) [" <> genIC is <> "]")
  where functionName :: forall ann. Doc ann
        functionName = "collectExport" <> pretty sceScope
        genICBind :: Int -> Doc ann
        genICBind i =
          "ic" <> pretty i <+> "=" <+>
          functionName <+> "(" <> pretty i <+> ":" <+> "p)" <+> "e" <> pretty i
        genICMaps = genComma (\i -> "icMap ic" <> pretty i)
        genIC = genComma (\i -> "ic" <> pretty i)
        exports = filterExports $ getScopeRules env con

-- genIndexPathConstr :: Doc ann -> Lang -> QName -> (String, [Type]) -> Doc ann
-- genIndexPathConstr ann lang mod (con, tys) =
--   let (is, childs) = numberChilds lang tys
--   in if null is then ""
--      else "indexPath (i : p) (" <> genFullName mod con <+> ann <> childs <> ") =" <> line <>
--           indent 2 ("case i of" <> line <>
--                     indent 2 (vsep $ L.map genOne is))
--   where genOne i = pretty i <+> "->" <+> "indexPath p e" <> pretty i

genICImportConstr :: ScopeCodeEnv -> (String, [Type]) -> Doc ann
genICImportConstr env@ScopeCodeEnv{..} (con, tys) =
  functionName <+> "m [" <> genComma genE is <> "] (" <> genFullName sceModule con <+> childs <> ") =" <|>
     indent 2 ("RefNode [" <+>
               align (genCommaLine genOne $ flip take fromOne $ maximum $ 0 : is) <+> "]")
  where functionName :: forall ann. Doc ann
        functionName = "collectImport" <> pretty sceScope
        (is, childs) = numberChilds env tys
        genE i = "IC" <+> "m" <> pretty i <+> "cs" <> pretty i
        genOne i
          | i `elem` is = functionName <+> allImports i <+> "cs" <> pretty i <+> "e" <> pretty i
          | otherwise   = "RefOmit"
        rs = getScopeRules env con
        imports = filterImports rs
        allImports i =
          let binds = filterBinds rs i
              bindsDoc = "Map.unionsWith (++) [" <> genComma (\i -> "m" <> pretty i) binds <> "]"
          in "(" <> (if i `elem` imports then "Map.unionWith (++) m $" <+> bindsDoc
                     else bindsDoc) <> ")"

genServerImport :: Doc ann
genServerImport = [r|module Server.Scope where
import qualified Server.Lang as Lang|]

genLibImport :: Doc ann
genLibImport = [r|module Lib.Scope where
import qualified Lib.Lang as Lang|]

genPreamble :: Doc ann -> Doc ann
genPreamble header = header <|> [r|
import qualified Data.Map as Map
import qualified Data.List as List
import qualified Lib.Meta.Identifier as Identifier

type Location = [Int]
type LocationTable = Map.Map Identifier.Id [Location]

data ExportedId = IC LocationTable [ExportedId]
  deriving Show

data References
  = RefNode [References]
  | RefVar  [Location]
  | RefOmit
  deriving Show

icMap :: ExportedId -> LocationTable
icMap (IC m _) = m

newtype SExp = SExp { unSExp :: String }

instance Show SExp where
  show = unSExp

showLocationSExp :: [Location] -> SExp
showLocationSExp locs = SExp $ "(" ++ concatMap showSexp locs ++ ")"
  where showSexp :: Location -> String
        showSexp xs = "(" ++ (List.intercalate " " $ map show xs) ++ ")"

indexReferences :: References -> Location -> [Location]
indexReferences RefOmit _     = []
indexReferences (RefVar m) [] = m
indexReferences (RefNode cs) (i:is)
  | i <= length cs = indexReferences (cs !! (i - 1)) is
  | otherwise      = []

filterMinRef :: References -> References -> References
filterMinRef _ RefOmit              = RefOmit
filterMinRef imports (RefNode refs) = RefNode $ flip map refs $ filterMinRef imports
filterMinRef imports (RefVar loc)   = RefVar $ filter isMin loc
  where farther p q = elem p $ indexReferences imports q
        isMin p = all (not . farther p) $ List.delete p loc
|]

interfaceTemplate :: String -> Doc ann
interfaceTemplate sname' = [r|
class |] <> scopeable <> [r| a where
  |] <> collectExport <> [r| :: Location -> a -> ExportedId
  --              imports at root  exports at childs
  |] <> collectImport <> [r| :: LocationTable -> [ExportedId] -> a -> References

instance |] <> scopeable <> [r| Identifier.Id where
  |] <> collectExport <> [r| p x = IC (Map.singleton x [reverse p]) []
  |] <> collectImport <> [r| m [] x = RefVar $ Map.findWithDefault [] x m
  -- indexPath [] x = x

|] <> crossReference <> [r| :: |] <> scopeable <> [r| a => a -> References
|] <> crossReference <> [r| e =
  let IC _ cs = |] <> collectExport <> [r| [] e
      raw = |] <> collectImport <> [r| Map.empty cs e
  in filterMinRef raw raw
|]
  where sname = pretty sname'
        scopeable = "Scopeable" <> sname
        collectImport = "collectImport" <> sname
        collectExport = "collectExport" <> sname
        crossReference = "crossReference" <> sname

vsep'' :: [Doc ann] -> Doc ann
vsep'' = concatWith (<|>)

genScopeType :: ScopeCodeEnv -> DataDeclaration -> Doc ann
genScopeType env@ScopeCodeEnv{..} DataDeclaration{..} =
  "instance Scopeable" <> pretty sceScope <+> pretty sceModule <> "." <> pretty ddTypeName <+> "where"
  <|> indent 2 (vsep'' $ L.map (genICExportConstr env) ddConstructors)
  <|> indent 2 (vsep'' $ L.map (genICImportConstr env) ddConstructors)
  <> line
  -- <|> indent 2 (vsep'' $ L.map (genIndexPathConstr ann lang mod) ddConstructors)

genScope :: Doc ann -> (forall ann. Doc ann) -> Lang -> Doc ann
genScope header ann lang@Lang{..} =
      genPreamble header
  <|> vsep'' (L.map (interfaceTemplate . fst) langScope)
  <|> vsep'' (L.map genScopeModule scopeAndModule)
  where scopeAndModule = [ (scope, mod) | scope <- L.map fst langScope,
                                          mod <- fst langModules ]
        genScopeModule (scope, mod@Module{..}) =
          vsep'' $ L.map (genScopeType env) $ filter (hasAnn scope) typeDecl
            where env = ScopeCodeEnv { sceExtraParam = ann
                                     , sceLang = lang
                                     , sceModule = moduleName
                                     , sceScope = scope
                                     }
        hasAnn scope DataDeclaration{..} = withScopeAnnotation scope ddAnnotation

generateLibScopeCode :: FilePath -> Lang -> IO ()
generateLibScopeCode path lang =
  createAndWriteFile (path </> "build/Lib/Scope.hs")
  (show $ genScope genLibImport "" lang)

generateServerScopeCode :: FilePath -> Lang -> IO ()
generateServerScopeCode path lang =
  createAndWriteFile (path </> "build/Server/Scope.hs")
  (show $ genScope genServerImport "_ " lang)

data PathLoc = 
