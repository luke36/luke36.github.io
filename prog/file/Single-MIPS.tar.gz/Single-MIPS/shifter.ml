open Hardcaml

module I = struct
  type 'a t = { src : 'a; [@bits 32] shamt : 'a; [@bits 32] typ : 'a [@bits 2] }
  [@@deriving sexp_of, hardcaml]
end

module O = struct
  type 'a t = { res : 'a [@bits 32] } [@@deriving sexp_of, hardcaml]
end

let create _scope (_input : Signal.t I.t) : Signal.t O.t = raise @@ Failure "sb"
